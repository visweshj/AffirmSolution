package com.affirm.loan;

import com.affirm.loan.service.LoanYieldService;

import java.util.Objects;

public class LoanServiceMain {

    public static void main(String[] args) {
        if (args.length == 3) {
            // using file override from Input Args
            LoanYieldService.getInstance(args[0], args[1], args[2]).calculateLoanYield();
        } else {
            // picking up inputs from default location

            LoanYieldService.getInstance(Objects.requireNonNull(ClassLoader.getSystemClassLoader().getResource("facilities.csv")).getFile(),
                    Objects.requireNonNull(ClassLoader.getSystemClassLoader().getResource("covenants.csv")).getFile(),
                    Objects.requireNonNull(ClassLoader.getSystemClassLoader().getResource("loans.csv")).getFile()).calculateLoanYield();
        }
    }
}
