package com.affirm.loan.service;

import com.affirm.loan.domain.*;
import com.affirm.loan.helper.YieldCalculationHelper;
import com.affirm.loan.util.CSVUtil;
import com.affirm.loan.util.CommonUtil;
import org.javatuples.Pair;
import org.javatuples.Triplet;

import java.util.*;
import java.util.stream.Collectors;

import static com.affirm.loan.schema.CSVSchemas.*;

public class LoanYieldService {

    private final String facilitiesFileName;
    private final String covenantsFileName;    private final String loansFileName;

    private LoanYieldService(String facilitiesFileName, String covenantsFileName, String loansFileName) {
        this.facilitiesFileName = facilitiesFileName;
        this.loansFileName = loansFileName;
        this.covenantsFileName = covenantsFileName;
    }

    private static LoanYieldService instance;

    public static LoanYieldService getInstance(String facilitiesFileName, String covenantsFileName, String loansFileName) {
        if (instance == null) instance = new LoanYieldService(facilitiesFileName, covenantsFileName, loansFileName);
        return instance;
    }

    /**
     * service function to consume the inputs, calculate loan assignments
     * and corresponding yields
     */
    public void calculateLoanYield() {
        Map<Integer, Facility> facilities = CSVUtil.loadAsTable(facilitiesFileName, Facility.class, FACILITY_SCHEMA, Facility::getFacilityId);
        List<Loan> loans = CSVUtil.loadFromSource(loansFileName, Loan.class, LOAN_SCHEMA);

        Set<Pair<Covenant, Set<String>>> covenants = CSVUtil.loadFromSource(covenantsFileName, Covenant.class, COVENANT_SCHEMA).stream()
                .collect(Collectors.toMap(Covenant::getFacilityId, CommonUtil::returnAsCollection, CommonUtil::mergeCollections)).entrySet()
                .stream()
                .map(covenantsByFacility -> Triplet.with(covenantsByFacility.getKey(), covenantsByFacility.getValue().stream()
                                .filter(covenant -> covenant.getMaxDefaultLikelihood() != null)
                                .findFirst().get()
                        , covenantsByFacility.getValue().stream()
                                .map(Covenant::getBannedState)
                                .collect(Collectors.toSet()))) // Accumulate by Default likelihood and a list of states where its banned
                .sorted((a, b) -> compareMaxDefaultLikelihood(a.getValue1(), b.getValue1())) // sort the covenants by min default likelihood
                .map(triple -> Pair.with(triple.getValue1(), triple.getValue2()))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        List<Triplet<Loan, Covenant, Facility>> assignments = loans.stream()
                .map(loan -> assignToCheapestFacility(loan, covenants, facilities))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        Pair<Collection<LoanAssignment>, Collection<Yield>> yieldsAndAssignments = YieldCalculationHelper.calculateYields(assignments);

        // save the processed loan assignments and expected yields
        CSVUtil.saveToFile("assignments.csv", LoanAssignment.class, ASSIGNMENT_SCHEMA, yieldsAndAssignments.getValue0());
        CSVUtil.saveToFile("yields.csv", Yield.class, YIELD_SCHEMA, yieldsAndAssignments.getValue1());

        System.out.println("All loans processed!");
    }

    private Triplet<Loan, Covenant, Facility> assignToCheapestFacility(Loan loan, Set<Pair<Covenant, Set<String>>> covenants, Map<Integer, Facility> facilities) {
        Optional<Covenant> cheapestPossibleCovenant = covenants.stream()
                .filter(covenant -> isCovenantAssignable(loan, covenant)
                        && facilities.get(covenant.getValue0().getFacilityId()).getAmount() >= loan.getAmount()) // validate if the facility can accept more loans
                .map(Pair::getValue0)
                .findFirst();
        return cheapestPossibleCovenant.map(covenant -> performAssignment(loan, covenant, facilities)) // if a cheap covenant is found, assign to loan
                .orElse(null); // unable to assign loan to a covenant
    }

    // Method can be expanded in future to account for new criteria
    private boolean isCovenantAssignable(Loan loan, Pair<Covenant, Set<String>> covenant) {
        return covenant.getValue0().getMaxDefaultLikelihood() >= loan.getDefaultLikelihood() // find the least possible default likelihood
                && !covenant.getValue1().contains(loan.getState()); // check if states is not banned for the facility
    }

    private Triplet<Loan, Covenant, Facility> performAssignment(Loan loan, Covenant covenant, Map<Integer, Facility> facilities) {
        // adjust the amount that a facility can lend by negating the successful loan assignment
        Facility assignedFacility = facilities.computeIfPresent(covenant.getFacilityId(), (key, facility) -> {
            facility.setAmount(facility.getAmount() - loan.getAmount());
            return facility;
        });
        return Triplet.with(loan, covenant, assignedFacility);
    }

    private int compareMaxDefaultLikelihood(Covenant a, Covenant b) {
        return a.getMaxDefaultLikelihood().compareTo(b.getMaxDefaultLikelihood());
    }


}
