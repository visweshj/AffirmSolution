package com.affirm.loan.error;

public class AffirmException extends RuntimeException{
    private final String errorMessage;

    public AffirmException(String errorMessage, Throwable err){
        super(err);
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
