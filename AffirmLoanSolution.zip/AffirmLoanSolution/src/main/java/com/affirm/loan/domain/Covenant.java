package com.affirm.loan.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
        "facility_id",
        "max_default_likelihood",
        "bank_id",
        "banned_state"
})
public class Covenant {
    @JsonProperty("bank_id")
    private int bankId;
    @JsonProperty("facility_id")
    private int facilityId;
    @JsonProperty("max_default_likelihood")
    private Float maxDefaultLikelihood;
    @JsonProperty("banned_state")
    private String bannedState;

    public int getBankId() {
        return bankId;
    }

    public void setBankId(int bankId) {
        this.bankId = bankId;
    }

    public int getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(int facilityId) {
        this.facilityId = facilityId;
    }

    public Float getMaxDefaultLikelihood() {
        return maxDefaultLikelihood;
    }

    public void setMaxDefaultLikelihood(Float maxDefaultLikelihood) {
        this.maxDefaultLikelihood = maxDefaultLikelihood;
    }

    public String getBannedState() {
        return bannedState;
    }

    public void setBannedState(String bannedState) {
        this.bannedState = bannedState;
    }
}
