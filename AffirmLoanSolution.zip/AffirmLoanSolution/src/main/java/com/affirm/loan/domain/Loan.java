package com.affirm.loan.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
        "interest_rate",
        "amount",
        "id",
        "default_likelihood",
        "state"
})
public class Loan {
    @JsonProperty("id")
    private int loanId;
    @JsonProperty("state")
    private String state;
    @JsonProperty("amount")
    private int amount;
    @JsonProperty("default_likelihood")
    private float defaultLikelihood;
    @JsonProperty("interest_rate")
    private float interestRate;

    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public float getDefaultLikelihood() {
        return defaultLikelihood;
    }

    public void setDefaultLikelihood(float maxDefaultLikelihood) {
        this.defaultLikelihood = maxDefaultLikelihood;
    }

    public float getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(float interestRate) {
        this.interestRate = interestRate;
    }
}
