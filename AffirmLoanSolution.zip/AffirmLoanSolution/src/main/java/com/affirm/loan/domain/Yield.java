package com.affirm.loan.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
        "facility_id",
        "expected_yield"
})
public class Yield {
    @JsonProperty("facility_id")
    private int facilityId;
    @JsonProperty("expected_yield")
    private float expectedYield;

    public int getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(int facilityId) {
        this.facilityId = facilityId;
    }

    public float getExpectedYield() {
        return Math.round(expectedYield);
    }

    public void setExpectedYield(float expectedYield) {
        this.expectedYield = expectedYield;
    }
}
