package com.affirm.loan.util;

import java.util.ArrayList;
import java.util.List;

public class CommonUtil {
    public static <T> List<T> returnAsCollection(T element){
        List<T> results = new ArrayList<>();
        results.add(element);
        return results;
    }

    public static <T> List<T> mergeCollections(List<T> a, List<T> b){
        a.addAll(b);
        return a;
    }
}
