package com.affirm.loan.helper;

import com.affirm.loan.domain.*;
import org.javatuples.Pair;
import org.javatuples.Triplet;

import java.util.*;

public class YieldCalculationHelper {

    public static Pair<Collection<LoanAssignment>, Collection<Yield>> calculateYields(List<Triplet<Loan, Covenant, Facility>> assignments) {
        List<LoanAssignment> loanAssignments = new ArrayList<>();
        Map<Integer, Yield> yields = new HashMap<>();
        for (Triplet<Loan, Covenant, Facility> assignment : assignments) {
            LoanAssignment loanAssignment = new LoanAssignment();
            Loan loan = assignment.getValue0();
            Facility facility = assignment.getValue2();
            loanAssignment.setLoanId(loan.getLoanId());
            loanAssignment.setFacilityId(facility.getFacilityId());
            loanAssignments.add(loanAssignment);

            // Keep accumulating the yields for the assignment by keying on the facility id
            yields.compute(facility.getFacilityId(), (facilityId, yield) -> {
                Yield newYield = new Yield();
                newYield.setFacilityId(facilityId);
                // Expected Yield Calculation
                float expectedYield = ((1 - loan.getDefaultLikelihood()) * loan.getInterestRate() * loan.getAmount())
                        - (loan.getDefaultLikelihood() * loan.getAmount())
                        - (facility.getInterestRate() * loan.getAmount());
                if (yield != null)
                    expectedYield += yield.getExpectedYield();
                newYield.setExpectedYield(expectedYield);
                return newYield;
            });

        }
        return Pair.with(loanAssignments, yields.values());

    }
}
