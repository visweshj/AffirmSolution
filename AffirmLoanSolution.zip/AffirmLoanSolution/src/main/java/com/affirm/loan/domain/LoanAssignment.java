package com.affirm.loan.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({
        "loan_id",
        "facility_id"
})
public class LoanAssignment {
    @JsonProperty("loan_id")
    private Integer loanId;
    @JsonProperty("facility_id")
    private Integer facilityId;

    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public Integer getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(Integer facilityId) {
        this.facilityId = facilityId;
    }
}
