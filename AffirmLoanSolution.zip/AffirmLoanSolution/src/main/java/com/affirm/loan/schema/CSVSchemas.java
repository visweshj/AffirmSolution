package com.affirm.loan.schema;

import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import static com.fasterxml.jackson.dataformat.csv.CsvSchema.ColumnType.NUMBER;
import static com.fasterxml.jackson.dataformat.csv.CsvSchema.ColumnType.STRING;

public class CSVSchemas {
    public static CsvSchema FACILITY_SCHEMA = CsvSchema.builder()
            .addColumn("amount", NUMBER)
                .addColumn("interest_rate", NUMBER)
                .addColumn("id", NUMBER)
                .addColumn("bank_id", NUMBER)
                .build().withHeader();

    public static CsvSchema LOAN_SCHEMA = CsvSchema.builder()
            .addColumn("interest_rate", NUMBER)
            .addColumn("amount", NUMBER)
            .addColumn("id", NUMBER)
            .addColumn("default_likelihood", NUMBER)
            .addColumn("state", STRING)
            .build().withHeader();

    public static CsvSchema COVENANT_SCHEMA = CsvSchema.builder()
            .addColumn("facility_id", NUMBER)
            .addColumn("max_default_likelihood", NUMBER)
            .addColumn("bank_id", NUMBER)
            .addColumn("banned_state", STRING)
            .build().withHeader();

    public static CsvSchema ASSIGNMENT_SCHEMA = CsvSchema.builder()
            .addColumn("loan_id", NUMBER)
            .addColumn("facility_id", NUMBER).build().withHeader();

    public static CsvSchema YIELD_SCHEMA = CsvSchema.builder()
            .addColumn("facility_id", NUMBER)
            .addColumn("expected_yield", NUMBER).build().withHeader();
}
