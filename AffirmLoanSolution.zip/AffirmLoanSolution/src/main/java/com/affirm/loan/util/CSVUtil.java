package com.affirm.loan.util;

import com.affirm.loan.error.AffirmException;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Service class to read from input sources
 */
public class CSVUtil {
    private static final CsvMapper CSV_MAPPER = new CsvMapper() ;
    private CSVUtil() {
    }

    /**
     * Utility method to read from input CSV source and convert to List and return them
     * @param fileName - file name with the location of the input source
     * @param type - object type representing the input type
     * @param <T> - Type of Input
     * @param schema - CSV schema representing the headers and type
     * @return - List of Values read from the input into source
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> loadFromSource(String fileName, Class<T> type, CsvSchema schema){
        try {
            return ((MappingIterator<T>) CSV_MAPPER.readerFor(type)
                    .with(schema)
                    .readValues(new File(fileName)))
                    .readAll();
        } catch (IOException e) {
            System.out.printf("Error occurred while loading Data from source, %s%n", e.getMessage());
            throw new AffirmException(String.format("Error occurred while loading Data from source, %s%n", e.getMessage()), e);
        }
    }

    /**
     * Utility method to read from input CSV source and convert to a table and return them
     * @param fileName - file name with the location of the input source
     * @param type - object type representing the input type
     * @param <T> - Type of Input
     * @param schema - CSV schema representing the headers and type
     * @param keyFunction - function to generate the key for the record
     * @return - List of Values read from the input into source
     */
    @SuppressWarnings("unchecked")
    public static <T, K> Map<K, T> loadAsTable(String fileName, Class<T> type, CsvSchema schema, Function<T, K> keyFunction){
        try {
            return ((MappingIterator<T>) CSV_MAPPER.readerFor(type)
                    .with(schema)
                    .readValues(new File(fileName)))
                    .readAll()
                    .stream()
                    .collect(Collectors.toMap(keyFunction, Function.identity()));
        } catch (IOException e) {
            System.out.printf("Error occurred while loading Data as Table, %s%n", e.getMessage());
            throw new AffirmException(String.format("Error occurred while loading Data as Table, %s%n", e.getMessage()), e);
        }
    }

    /**
     *
     * @param fileName - Location of the file to save to
     * @param type - object type representing the output
     * @param schema - CSV schema representing the headers and type
     * @param data - Data to write to
     * @param <T> - Java Type of output
     */
    public static <T> void saveToFile(String fileName, Class<T> type, CsvSchema schema, Collection<T> data) {
        try {
            CSV_MAPPER.writerWithSchemaFor(type)
                    .with(schema)
                    .writeValues(new File(fileName))
                    .writeAll(data);
        } catch (IOException e) {
            System.out.printf("Error occurred while writing Data, %s%n", e.getMessage());
            throw new AffirmException(String.format("Error occurred while writing Data, %s%n", e.getMessage()), e);
        }
    }


}
